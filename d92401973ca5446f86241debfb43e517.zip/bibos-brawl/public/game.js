// BIBOS BRAWL — cliente
const canvas=document.getElementById('game'), ctx=canvas.getContext('2d');
const $=id=>document.getElementById(id);
let W=0,H=0; function resize(){W=canvas.width=innerWidth;H=canvas.height=innerHeight;}
addEventListener('resize',resize);resize();

// ===== 12 BIBOS (mesmos dados do servidor) =====
const BIBOS=[
 {id:0,name:'Zapos',ico:'🐸',color:'#4ade80',hp:7200,speed:170,dmg:900,rate:.9,bullets:1,spread:.12,bspeed:520,range:380,attack:'aoe',superName:'Salto Monumental',gadgetName:'Língua Pegajosa',passive:'Pele Venenosa'},
 {id:1,name:'Barata Baba',ico:'🪳',color:'#a16207',hp:4800,speed:260,dmg:700,rate:.25,bullets:1,spread:.15,bspeed:620,range:260,attack:'melee',superName:'Sobrevivente',gadgetName:'Exoesqueleto',passive:'Imune a Veneno'},
 {id:2,name:'Ratatuili',ico:'🐁',color:'#94a3b8',hp:5400,speed:210,dmg:1100,rate:.8,bullets:1,spread:.1,bspeed:560,range:400,attack:'aoe',superName:'Toqueia',gadgetName:'Rato de Borracha',passive:'Pés Leves'},
 {id:3,name:'Largatixa Goat',ico:'🦎',color:'#22d3ee',hp:5600,speed:190,dmg:800,rate:.7,bullets:1,spread:.1,bspeed:540,range:420,attack:'shot',stunOnHit:1,superName:'Cauda Falsa',gadgetName:'Parede de Vidro',passive:'Regeneração'},
 {id:4,name:'Besba',ico:'🐌',color:'#f472b6',hp:9000,speed:110,dmg:700,rate:1,bullets:1,spread:.1,bspeed:460,range:380,attack:'puddle',superName:'Concha Gigante',gadgetName:'Babada Turbo',passive:'Concha Dura'},
 {id:5,name:'Babanha',ico:'🕷️',color:'#a78bfa',hp:5200,speed:175,dmg:850,rate:.6,bullets:1,spread:.1,bspeed:540,range:440,attack:'shot',slowOnHit:1.5,superName:'Teia de Captura',gadgetName:'Fio de Seda',passive:'Sensibilidade'},
 {id:6,name:'Bribo',ico:'🦗',color:'#84cc16',hp:5000,speed:205,dmg:750,rate:.5,bullets:1,spread:.08,bspeed:600,range:480,attack:'ricochet',superName:'Grito Sônico',gadgetName:'Pulo de Grilo',passive:'Pernas Saltadoras'},
 {id:7,name:'Pocket Ants',ico:'🐜',color:'#78350f',hp:6000,speed:185,dmg:1000,rate:.6,bullets:1,spread:.1,bspeed:560,range:300,attack:'melee',superName:'Enxame',gadgetName:'Folha de Formiga',passive:'Força de Formiga'},
 {id:8,name:'Binhobo',ico:'🐛',color:'#a3e635',hp:5800,speed:180,dmg:800,rate:.65,bullets:1,spread:.1,bspeed:540,range:360,attack:'shot',blindOnHit:1.2,superName:'Terremoto',gadgetName:'Túnel Rápido',passive:'Regeneração na Terra'},
 {id:9,name:'Besborbião',ico:'🦂',color:'#dc2626',hp:6400,speed:165,dmg:1300,rate:.85,bullets:1,spread:.06,bspeed:520,range:280,attack:'pierce',poisonOnHit:3,superName:'Ferrão Venenoso',gadgetName:'Armadura de Quitina',passive:'Cauda de Aço'},
 {id:10,name:'Buabinha',ico:'🐞',color:'#ef4444',hp:5200,speed:195,dmg:500,rate:.55,bullets:5,spread:.45,bspeed:580,range:360,attack:'shotgun',critChance:.2,superName:'Enxame da Sorte',gadgetName:'Asa de Joaninha',passive:'Sorte'},
 {id:11,name:'Bizu',ico:'🦟',color:'#64748b',hp:4600,speed:240,dmg:650,rate:.35,bullets:1,spread:.12,bspeed:660,range:340,attack:'rapid',lifesteal:true,superName:'Praga',gadgetName:'Zumbido',passive:'Voo'},
];
const MODES=[{id:'gemgrab',name:'💎 Gem Grab'},{id:'showdown',name:'💀 Showdown'},{id:'brawlball',name:'⚽ Brawl Ball'},{id:'heist',name:'💰 Heist'},{id:'bounty',name:'⭐ Bounty'}];
const MAPS=[{name:'Jardim das Gemas',bg:'#1a3a2a',walls:[{x:350,y:250,w:160,h:35},{x:350,y:250,w:35,h:160},{x:1090,y:250,w:160,h:35},{x:1215,y:250,w:35,h:160},{x:350,y:915,w:160,h:35},{x:350,y:860,w:35,h:160},{x:1090,y:915,w:160,h:35},{x:1215,y:860,w:35,h:160},{x:750,y:500,w:100,h:200},{x:200,y:550,w:35,h:140},{x:1365,y:550,w:35,h:140},{x:600,y:180,w:140,h:30},{x:860,y:180,w:140,h:30},{x:600,y:990,w:140,h:30},{x:860,y:990,w:140,h:30}]},{name:'Lata de Lixo',bg:'#2a2520',walls:[{x:100,y:300,w:300,h:35},{x:1200,y:300,w:300,h:35},{x:100,y:865,w:300,h:35},{x:1200,y:865,w:300,h:35},{x:400,y:300,w:35,h:250},{x:1165,y:300,w:35,h:250},{x:400,y:650,w:35,h:250},{x:1165,y:650,w:35,h:250},{x:700,y:200,w:200,h:35},{x:700,y:965,w:200,h:35},{x:300,y:550,w:140,h:35},{x:1160,y:550,w:140,h:35},{x:750,y:550,w:100,h:100}]},{name:'Campo de Futebol',bg:'#14532d',walls:[{x:0,y:500,w:1600,h:30},{x:700,y:0,w:200,h:150},{x:700,y:1050,w:200,h:150},{x:300,y:300,w:120,h:30},{x:1180,y:300,w:120,h:30},{x:300,y:870,w:120,h:30},{x:1180,y:870,w:120,h:30}]},{name:'Formigueiro',bg:'#3a2510',walls:[{x:250,y:200,w:120,h:120},{x:1230,y:200,w:120,h:120},{x:250,y:880,w:120,h:120},{x:1230,y:880,w:120,h:120},{x:700,y:450,w:200,h:30},{x:700,y:720,w:200,h:30},{x:500,y:300,w:30,h:150},{x:1070,y:300,w:30,h:150},{x:500,y:750,w:30,h:150},{x:1070,y:750,w:30,h:150}]},{name:'Praça das Estrelas',bg:'#1e2a4a',walls:[{x:400,y:400,w:200,h:30},{x:1000,y:400,w:200,h:30},{x:400,y:770,w:200,h:30},{x:1000,y:770,w:200,h:30},{x:750,y:250,w:100,h:100},{x:750,y:850,w:100,h:100},{x:150,y:600,w:30,h:150},{x:1420,y:600,w:30,h:150}]}];
const ARENA={w:1600,h:1200};

// ===== PROGRESSO (localStorage) =====
let prog=JSON.parse(localStorage.getItem('bibosProg')||'null')||{trophies:0,coins:100,unlocked:[0,1,6,10],levels:{},selectedBibo:0,selectedMode:0};
function saveProg(){localStorage.setItem('bibosProg',JSON.stringify(prog));}
function show(id){['menu','joinScreen','lobby'].forEach(s=>$(s).style.display=s===id?'flex':'none');}

// ===== MENU: grid de bibos =====
let selectedBibo=prog.selectedBibo||0, selectedMode=prog.selectedMode||0;
function renderBiboGrid(){
  const g=$('biboGrid'); g.innerHTML='';
  BIBOS.forEach((b,i)=>{
    const unlocked=prog.unlocked.includes(i);
    const c=document.createElement('div');
    c.className='biboCard'+(i===selectedBibo?' sel':'')+(unlocked?'':' locked');
    c.innerHTML=`<div class="ico">${b.ico}</div><div class="nm">${b.name.split(' ')[0]}</div>${unlocked?'':'<div>🔒</div>'}`;
    c.onclick=()=>{ if(unlocked){selectedBibo=i;prog.selectedBibo=i;saveProg();renderBiboGrid();showBiboInfo();} else if(prog.coins>=50){prog.coins-=50;prog.unlocked.push(i);saveProg();renderBiboGrid();updateProgInfo();toast(`${b.ico} ${b.name} desbloqueado!`);} else toast('Moedas insuficientes (50)'); };
    g.appendChild(c);
  });
}
function showBiboInfo(){
  const b=BIBOS[selectedBibo];
  $('biboInfo').innerHTML=`<b>${b.ico} ${b.name}</b> — ❤️${b.hp} ⚔️${b.dmg} 👟${b.speed} 🎯${b.range}<br><b>SUPER:</b> ${b.superName} · <b>GADGET:</b> ${b.gadgetName}<br><b>PASSIVA:</b> ${b.passive}`;
}
function renderModes(){
  const r=$('modeRow'); r.innerHTML='';
  MODES.forEach((m,i)=>{
    const b=document.createElement('div'); b.className='modeBtn'+(i===selectedMode?' sel':'');
    b.textContent=m.name; b.onclick=()=>{selectedMode=i;prog.selectedMode=i;saveProg();renderModes();};
    r.appendChild(b);
  });
}
function updateProgInfo(){ $('progInfo').textContent=`🏆 ${prog.trophies} troféus · 🪙 ${prog.coins} moedas · 🔓 ${prog.unlocked.length}/12 bibos`; }
function toast(msg){ const t=$('toast'); t.textContent=msg; t.style.opacity=1; setTimeout(()=>t.style.opacity=0,1800); }
renderBiboGrid();showBiboInfo();renderModes();updateProgInfo();

// ===== ÁUDIO (WebAudio sintetizado) =====
let AC=null; function audio(){ if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)();}catch(e){}} return AC; }
function beep(freq,dur,type='square',vol=.08){ const ac=audio(); if(!ac)return; const o=ac.createOscillator(),g=ac.createGain(); o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(vol,ac.currentTime);g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+dur);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+dur); }
function sfxShoot(){beep(600+Math.random()*200,.08,'square',.05);}
function sfxHit(){beep(180,.1,'sawtooth',.06);}
function sfxSuper(){beep(300,.3,'sawtooth',.1);setTimeout(()=>beep(500,.3,'sawtooth',.1),100);}
function sfxKill(){beep(800,.15,'square',.08);setTimeout(()=>beep(1100,.2,'square',.08),120);}

// ===== INPUT =====
const myInput={mx:0,my:0,ax:1,ay:0,fire:false,super:false,gadget:false};
const keys={}; addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true; if(e.key.toLowerCase()==='q')myInput.super=true; if(e.key.toLowerCase()==='e')myInput.gadget=true;});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
const mouse={x:0,y:0,down:false};
canvas.addEventListener('mousemove',e=>{mouse.x=e.clientX;mouse.y=e.clientY;});
canvas.addEventListener('mousedown',()=>mouse.down=true); addEventListener('mouseup',()=>mouse.down=false);
// joysticks multitoque (identificador por dedo)
function setupJoy(elId,knobId,cb){
  const el=$(elId),knob=$(knobId);let active=false,cx=0,cy=0,touchId=null;const R=40;
  const move=(x,y)=>{if(!active)return;let dx=x-cx,dy=y-cy;const d=Math.hypot(dx,dy);if(d>R){dx=dx/d*R;dy=dy/d*R;}knob.style.transform=`translate(${dx}px,${dy}px)`;cb(dx/R,dy/R);};
  const end=()=>{active=false;touchId=null;knob.style.transform='translate(0,0)';cb(0,0);};
  const find=list=>{for(const t of list)if(t.identifier===touchId)return t;return null;};
  el.addEventListener('touchstart',e=>{e.preventDefault();for(const t of e.changedTouches){const r=el.getBoundingClientRect();if(t.clientX>=r.left&&t.clientX<=r.right&&t.clientY>=r.top&&t.clientY<=r.bottom){touchId=t.identifier;cx=r.left+r.width/2;cy=r.top+r.height/2;active=true;move(t.clientX,t.clientY);}}},{passive:false});
  el.addEventListener('touchmove',e=>{e.preventDefault();if(!active||touchId===null)return;const t=find(e.touches);if(t)move(t.clientX,t.clientY);},{passive:false});
  const endH=e=>{e.preventDefault();for(const t of e.changedTouches)if(t.identifier===touchId)end();};
  el.addEventListener('touchend',endH);el.addEventListener('touchcancel',endH);
}
setupJoy('joyMove','knobMove',(x,y)=>{myInput.mx=x;myInput.my=y;});
setupJoy('joyAim','knobAim',(x,y)=>{myInput.ax=x||1;myInput.ay=y;myInput.fire=Math.hypot(x,y)>0.15;});
$('fireBtn').addEventListener('touchstart',e=>{e.preventDefault();myInput.fire=true;autoAim();},{passive:false});
$('fireBtn').addEventListener('touchend',e=>{e.preventDefault();myInput.fire=false;},{passive:false});
$('fireBtn').addEventListener('mousedown',()=>{myInput.fire=true;autoAim();});
addEventListener('mouseup',()=>{if(!mouse.down)myInput.fire=false;});
$('superBtn').addEventListener('touchstart',e=>{e.preventDefault();myInput.super=true;},{passive:false});
$('superBtn').addEventListener('mousedown',()=>myInput.super=true);
$('gadgetBtn').addEventListener('touchstart',e=>{e.preventDefault();myInput.gadget=true;},{passive:false});
$('gadgetBtn').addEventListener('mousedown',()=>myInput.gadget=true);
function autoAim(){ if(game&&game.players&&myId){ const me=game.players[myId]; if(!me)return; let best=null,bd=1e9; for(const p of Object.values(game.players)){ if(p.team===me.team||!p.alive)continue; const d=Math.hypot(p.x-me.x,p.y-me.y); if(d<bd){bd=d;best=p;} } if(best){const a=Math.atan2(best.y-me.y,best.x-me.x);myInput.ax=Math.cos(a);myInput.ay=Math.sin(a);} } }

// teclado (PC)
setInterval(()=>{
  if(!inGame)return;
  let kx=0,ky=0;
  if(keys['w']||keys['arrowup'])ky-=1; if(keys['s']||keys['arrowdown'])ky+=1;
  if(keys['a']||keys['arrowleft'])kx-=1; if(keys['d']||keys['arrowright'])kx+=1;
  if(kx||ky){const l=Math.hypot(kx,ky);myInput.mx=kx/l;myInput.my=ky/l;}
  else if(!('ontouchstart'in window)){myInput.mx=0;myInput.my=0;}
  if(!('ontouchstart'in window)&&game&&game.players&&game.players[myId]){
    const me=game.players[myId]; const wx=mouse.x-cam.x, wy=mouse.y-cam.y;
    const a=Math.atan2(wy-me.y, wx-me.x); myInput.ax=Math.cos(a);myInput.ay=Math.sin(a);
    myInput.fire=mouse.down;
  }
},30);

// ===== REDE (online) =====
let socket=null, myId=null, inGame=false, mode='gemgrab', mapIdx=0;
function showJoin(){show('joinScreen');}
function nick(){return ($('nick').value||'Jogador').slice(0,12);}
function createRoom(){
  audio();
  socket=io(); mode=MODES[selectedMode].id; mapIdx=selectedMode;
  socket.emit('createRoom',{nick:nick(),bibo:selectedBibo,mode,mapIdx},r=>{
    if(r.ok){ myId=r.pid; $('roomCode').textContent=r.code; show('lobby'); toast('Sala criada!'); }
    else toast('Erro ao criar sala');
  });
  socket.on('started',()=>startMatch());
  socket.on('state',s=>{game=s;});
  socket.on('gameover',d=>endGame(d));
}
function joinRoom(){
  audio();
  socket=io();
  socket.emit('joinRoom',{nick:nick(),bibo:selectedBibo,code:$('codeInput').value},r=>{
    if(r.ok){ myId=r.pid; mode=MODES[selectedMode].id; mapIdx=selectedMode; startMatch(); }
    else toast(r.error||'Erro');
  });
  socket.on('started',()=>startMatch());
  socket.on('state',s=>{game=s;});
  socket.on('gameover',d=>endGame(d));
}
function startGame(){ if(socket)socket.emit('startGame'); startMatch(); }

// ===== MODO OFFLINE (engine local compacta + bots) =====
let offline=null;
function startOffline(){
  audio(); mode=MODES[selectedMode].id; mapIdx=selectedMode;
  offline={players:{},bullets:[],minions:[],powerups:[],gems:[],t:150,over:false,winner:null,effects:[],puddles:[],blueScore:0,orangeScore:0,gemsBlue:0,gemsOrange:0,ball:{x:800,y:600,vx:0,vy:0},ballCarrier:null,safeBlue:{hp:15000,maxhp:15000},safeOrange:{hp:15000,maxhp:15000}};
  myId='me';
  const me={id:'me',nick:nick(),bibo:selectedBibo,team:'blue',isBot:false,x:200,y:600,hp:BIBOS[selectedBibo].hp,maxhp:BIBOS[selectedBibo].hp,alive:true,angle:0,superCharge:0,gadgetCharges:2,gadgetCd:0,stun:0,slow:0,poison:0,invisible:0,invuln:0,flying:0,rolling:0,shield:0,kills:0,stars:0,gems:0,hasBall:false,minions:0,lastShot:0,secondLife:false};
  offline.players.me=me;
  const botNames=['BotZika','NoobMaster','SniperBR','XxKill','Falcão','Trovão'];
  for(let i=0;i<5;i++){
    const team=i<2?'blue':'orange';
    const bibo=Math.floor(Math.random()*12);
    offline.players['bot'+i]={id:'bot'+i,nick:botNames[i],bibo,team,isBot:true,x:team==='blue'?200+Math.random()*150:1250+Math.random()*150,y:300+Math.random()*600,hp:BIBOS[bibo].hp,maxhp:BIBOS[bibo].hp,alive:true,angle:0,superCharge:Math.random()*40,gadgetCharges:2,gadgetCd:0,stun:0,slow:0,poison:0,invisible:0,invuln:0,flying:0,rolling:0,shield:0,kills:0,stars:0,gems:0,hasBall:false,minions:0,lastShot:0,secondLife:false,skill:.6,strafeDir:1,strafeT:0,thinkT:0};
  }
  for(let i=0;i<4;i++)offline.powerups.push({x:200+Math.random()*1200,y:150+Math.random()*900,type:['heal','dmg','speed'][i%3],taken:false});
  startMatch();
}
// engine offline (espelha servidor) — compacta
function collidesWall(x,y,r){ for(const w of MAPS[mapIdx].walls) if(x>w.x-r&&x<w.x+w.w+r&&y>w.y-r&&y<w.y+w.h+r) return true; return false; }
function offlineTick(){
  const st=offline, dt=1/30, now=performance.now()/1000;
  st.t-=dt;
  for(let i=st.effects.length-1;i>=0;i--){const e=st.effects[i];e.t-=dt;if(e.type==='ring')e.r+=e.max*dt*3;if(e.t<=0)st.effects.splice(i,1);}
  if(st.powerups.every(p=>p.taken)&&Math.random()<0.02)st.powerups.push({x:200+Math.random()*1200,y:150+Math.random()*900,type:['heal','dmg','speed'][Math.floor(Math.random()*3)],taken:false});
  if(mode==='brawlball'){
    st.ball.x+=st.ball.vx*dt;st.ball.y+=st.ball.vy*dt;st.ball.vx*=0.98;st.ball.vy*=0.98;
    if(collidesWall(st.ball.x,st.ball.y,15)){st.ball.vx*=-0.6;st.ball.vy*=-0.6;}
    st.ball.x=Math.max(20,Math.min(ARENA.w-20,st.ball.x));st.ball.y=Math.max(20,Math.min(ARENA.h-20,st.ball.y));
    if(st.ball.x<40&&st.ball.y>500&&st.ball.y<700){st.orangeScore++;resetBall();if(st.orangeScore>=2){st.over=true;st.winner='orange';}}
    if(st.ball.x>ARENA.w-40&&st.ball.y>500&&st.ball.y<700){st.blueScore++;resetBall();if(st.blueScore>=2){st.over=true;st.winner='blue';}}
  }
  if(mode==='gemgrab'){
    if(st.gemsBlue>=10){st.gemTimer=(st.gemTimer||0)+dt;if(st.gemTimer>=15){st.over=true;st.winner='blue';}}else st.gemTimer=0;
    if(st.gemsOrange>=10){st.gemTimerO=(st.gemTimerO||0)+dt;if(st.gemTimerO>=15){st.over=true;st.winner='orange';}}else st.gemTimerO=0;
    if(!st.gems.length||st.gems.every(g=>g.taken))st.gems.push({x:800,y:600,taken:false});
  }
  if(st.t<=0&&!st.over){st.over=true;st.winner=st.blueScore>=st.orangeScore?'blue':'orange';}
  for(const p of Object.values(st.players)){
    if(!p.alive){p.respawnAt=p.respawnAt||now+4;if(now>p.respawnAt){p.alive=true;p.hp=p.maxhp;p.x=p.team==='blue'?200:1400;p.y=600;p.respawnAt=0;}continue;}
    if(p.isBot)botAI(p,st);
    const b=BIBOS[p.bibo], inp=p.isBot?p.input:myInput;
    if(p.stun>0)p.stun-=dt;if(p.slow>0)p.slow-=dt;if(p.poison>0){p.hp-=80*dt;p.poison-=dt;if(p.hp<=0){p.alive=false;p.respawnAt=now+4;continue;}}
    if(p.invuln>0)p.invuln-=dt;if(p.invisible>0)p.invisible-=dt;if(p.flying>0)p.flying-=dt;if(p.rolling>0)p.rolling-=dt;if(p.gadgetCd>0)p.gadgetCd-=dt;
    if(p.stun<=0){
      let vx=inp.mx||0,vy=inp.my||0;const vl=Math.hypot(vx,vy);if(vl>0){vx/=vl;vy/=vl;}
      let spd=b.speed*(p.slow>0?.4:1)*(p.rolling>0?2.2:1);
      if(p.bibo===1)spd=b.speed;
      const nx=p.x+vx*spd*dt,ny=p.y+vy*spd*dt;
      if(p.flying>0||!collidesWall(nx,p.y,22))p.x=Math.max(30,Math.min(ARENA.w-30,nx));
      if(p.flying>0||!collidesWall(p.x,ny,22))p.y=Math.max(30,Math.min(ARENA.h-30,ny));
    }
    if(inp.ax||inp.ay)p.angle=Math.atan2(inp.ay,inp.ax);
    for(const pu of st.powerups)if(!pu.taken&&Math.hypot(pu.x-p.x,pu.y-p.y)<30){pu.taken=true;if(pu.type==='heal')p.hp=Math.min(p.maxhp,p.hp+1500);if(pu.type==='speed')p.speedBoost=5;}
    if(mode==='gemgrab')for(const g of st.gems)if(!g.taken&&Math.hypot(g.x-p.x,g.y-p.y)<30){g.taken=true;p.gems++;if(p.team==='blue')st.gemsBlue++;else st.gemsOrange++;}
    if(mode==='brawlball'&&!st.ballCarrier&&Math.hypot(st.ball.x-p.x,st.ball.y-p.y)<35){p.hasBall=true;st.ballCarrier=p.id;}
    if(p.hasBall){st.ball.x=p.x;st.ball.y=p.y;}
    if(inp.fire&&p.stun<=0&&now-p.lastShot>b.rate){p.lastShot=now;fireWeapon(p,st);sfxShoot();}
    if(inp.super){if(p.superCharge>=100){p.superCharge=0;activateSuper(p,st);sfxSuper();}inp.super=false;}
    if(inp.gadget){if(p.gadgetCharges>0&&p.gadgetCd<=0){p.gadgetCharges--;p.gadgetCd=20;useGadget(p,st);}inp.gadget=false;}
  }
  // minions
  for(let i=st.minions.length-1;i>=0;i--){const m=st.minions[i];m.life-=dt;if(m.life<=0||m.hp<=0){st.minions.splice(i,1);continue;}if(m.isDecoy)continue;
    let tgt=null,bd=1e9;for(const p of Object.values(st.players)){if(p.team===m.team||!p.alive)continue;const d=Math.hypot(p.x-m.x,p.y-m.y);if(d<bd){bd=d;tgt=p;}}
    if(tgt){const a=Math.atan2(tgt.y-m.y,tgt.x-m.x);m.x+=Math.cos(a)*160*dt;m.y+=Math.sin(a)*160*dt;if(bd<30){tgt.hp-=600;m.hp-=200;if(tgt.hp<=0){tgt.alive=false;tgt.respawnAt=now+4;}}}}
  // balas
  for(let i=st.bullets.length-1;i>=0;i--){const bl=st.bullets[i];bl.x+=bl.vx*dt;bl.y+=bl.vy*dt;bl.life-=dt;let dead=bl.life<=0||bl.x<0||bl.x>ARENA.w||bl.y<0||bl.y>ARENA.h;
    if(!dead&&collidesWall(bl.x,bl.y,4)){if(bl.ricochet&&bl.bounces>0){bl.bounces--;if(Math.abs(bl.vx)>Math.abs(bl.vy))bl.vx*=-1;else bl.vy*=-1;}else dead=true;}
    if(!dead)for(const p of Object.values(st.players)){if(!p.alive||p.team===bl.team||bl.hit.includes(p.id))continue;if(Math.hypot(bl.x-p.x,bl.y-p.y)<24){
      p.hp-=bl.dmg;p.superCharge=Math.min(100,(p.superCharge||0)+0);if(bl.owner&&st.players[bl.owner])st.players[bl.owner].superCharge=Math.min(100,st.players[bl.owner].superCharge+bl.dmg*0.008);
      if(bl.slow)p.slow=Math.max(p.slow,bl.slow);if(bl.stun)p.stun=Math.max(p.stun,bl.stun);if(bl.poison)p.poison=Math.max(p.poison,bl.poison);
      sfxHit();if(p.hp<=0){p.alive=false;p.respawnAt=now+4;if(bl.owner&&st.players[bl.owner]){st.players[bl.owner].kills++;st.players[bl.owner].superCharge=Math.min(100,st.players[bl.owner].superCharge+25);sfxKill();}if(p.hasBall){p.hasBall=false;st.ballCarrier=null;st.ball.vx=0;st.ball.vy=0;}}
      if(bl.pierce){bl.hit.push(p.id);}else dead=true;break;}}
    if(dead)st.bullets.splice(i,1);}
  game={players:st.players,bullets:st.bullets,minions:st.minions,powerups:st.powerups,gems:st.gems,t:st.t,over:st.over,winner:st.winner,mapIdx,mode,blueScore:st.blueScore,orangeScore:st.orangeScore,gemsBlue:st.gemsBlue,gemsOrange:st.gemsOrange,ball:st.ball,ballCarrier:st.ballCarrier,safeBlue:st.safeBlue,safeOrange:st.safeOrange,effects:st.effects,puddles:st.puddles};
  if(st.over)endGame({winner:st.winner,blue:st.blueScore,orange:st.orangeScore});
}
function resetBall(){offline.ball={x:800,y:600,vx:0,vy:0};offline.ballCarrier=null;for(const p of Object.values(offline.players))p.hasBall=false;}
function botAI(p,st){
  p.thinkT-=1/30; if(!p.input)p.input={mx:0,my:0,ax:1,ay:0,fire:false,super:false,gadget:false};
  if(p.thinkT<=0){p.thinkT=.2+Math.random()*.2;let best=null,bd=1e9;for(const o of Object.values(st.players)){if(o.team===p.team||!o.alive)continue;const d=Math.hypot(o.x-p.x,o.y-p.y);if(d<bd){bd=d;best=o;}}p.target=best;p.bd=bd;}
  const inp=p.input,t=p.target,b=BIBOS[p.bibo];
  if(t&&p.bd<600){const ang=Math.atan2(t.y-p.y,t.x-p.x);const err=(Math.random()-.5)*(1-p.skill)*.8;inp.ax=Math.cos(ang+err);inp.ay=Math.sin(ang+err);inp.fire=p.bd<b.range*.9&&Math.random()<(.4+p.skill*.5);
    if(p.superCharge>=100&&Math.random()<.5)inp.super=true;else inp.super=false;
    const ideal=b.range*.6;if(p.bd>ideal){inp.mx=Math.cos(ang)*.8;inp.my=Math.sin(ang)*.8;}else{p.strafeT-=1/30;if(p.strafeT<=0){p.strafeT=.6;p.strafeDir*=-1;}inp.mx=Math.cos(ang+Math.PI/2)*p.strafeDir;inp.my=Math.sin(ang+Math.PI/2)*p.strafeDir;}}
  else{inp.mx=Math.sin(performance.now()*.001+p.id.length)*.5;inp.my=Math.cos(performance.now()*.0013)*.5;inp.fire=false;inp.super=false;}
}
function fireWeapon(p,st){const b=BIBOS[p.bibo],a=p.angle||0,n=b.bullets||1;for(let i=0;i<n;i++){const ang=a+(n>1?(i/(n-1)-.5)*b.spread*2:(Math.random()-.5)*b.spread);st.bullets.push({x:p.x+Math.cos(ang)*25,y:p.y+Math.sin(ang)*25,vx:Math.cos(ang)*b.bspeed,vy:Math.sin(ang)*b.bspeed,dmg:b.dmg,owner:p.id,team:p.team,life:b.range/b.bspeed,hit:[],pierce:b.attack==='pierce',ricochet:b.attack==='ricochet',bounces:b.attack==='ricochet'?3:0,slow:b.slowOnHit||0,stun:b.stunOnHit||0,poison:b.poisonOnHit||0});}}
function activateSuper(p,st){const b=BIBOS[p.bibo],a=p.angle||0;
  switch(p.bibo){
    case 0:p.invuln=.8;p.x+=Math.cos(a)*180;p.y+=Math.sin(a)*180;for(const e of enemiesOf(p,st))if(Math.hypot(e.x-p.x,e.y-p.y)<150){e.hp-=1500;e.stun=Math.max(e.stun,1);}st.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:150,color:b.color,t:.5});break;
    case 1:p.secondLife=true;break;
    case 2:p.invisible=6;break;
    case 3:st.minions.push({x:p.x,y:p.y,vx:0,vy:0,hp:1500,maxhp:1500,dmg:0,life:5,owner:p.id,team:p.team,isDecoy:true,color:b.color,size:22});p.invisible=4;break;
    case 4:p.invuln=2.5;p.rolling=2.5;break;
    case 5:for(const e of enemiesOf(p,st))if(Math.hypot(e.x-p.x,e.y-p.y)<300){e.stun=Math.max(e.stun,2);e.invisible=0;}st.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:300,color:b.color,t:.6});break;
    case 6:for(const e of enemiesOf(p,st)){const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<350){const ea=Math.atan2(e.y-p.y,e.x-p.x);e.x+=Math.cos(ea)*120;e.y+=Math.sin(ea)*120;}}st.bullets=[];break;
    case 7:for(let i=0;i<4;i++){const ang=Math.random()*6.28;st.minions.push({x:p.x+Math.cos(ang)*40,y:p.y+Math.sin(ang)*40,vx:0,vy:0,hp:400,maxhp:400,dmg:600,life:8,owner:p.id,team:p.team,color:b.color,size:10});}break;
    case 8:p.invuln=1.5;p.invisible=1.5;p.x+=Math.cos(a)*250;p.y+=Math.sin(a)*250;for(const e of enemiesOf(p,st))if(Math.hypot(e.x-p.x,e.y-p.y)<160){e.hp-=1800;e.stun=Math.max(e.stun,1);}st.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:160,color:b.color,t:.5});break;
    case 9:for(const e of enemiesOf(p,st)){const dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy);if(d<220&&Math.abs(Math.atan2(dy,dx)-a)<.9){e.hp-=1200;e.poison=Math.max(e.poison,5);p.hp=Math.min(p.maxhp,p.hp+600);}}break;
    case 10:for(const e of alliesOf(p,st)){e.hp=Math.min(e.maxhp,e.hp+1500);e.speedBoost=5;}st.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:250,color:'#f472b6',t:.6});break;
    case 11:for(const e of enemiesOf(p,st))if(Math.hypot(e.x-p.x,e.y-p.y)<280){e.hp-=1000;p.hp=Math.min(p.maxhp,p.hp+700);}st.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:280,color:'#64748b',t:.6});break;
  }
}
function useGadget(p,st){const a=p.angle||0;switch(p.bibo){case 1:p.shield=Math.max(p.shield||0,p.maxhp*.4);break;case 2:p.x+=Math.cos(a)*150;p.y+=Math.sin(a)*150;break;case 3:p.flying=Math.max(p.flying||0,3);break;case 6:p.x-=Math.cos(a)*120;p.y-=Math.sin(a)*120;break;case 7:p.shield=Math.max(p.shield||0,1200);break;case 10:p.flying=Math.max(p.flying||0,3);break;case 11:p.intang=1.5;break;default:break;}}
function enemiesOf(p,st){const a=[];for(const o of Object.values(st.players))if(o.team!==p.team&&o.alive)a.push(o);return a;}
function alliesOf(p,st){const a=[];for(const o of Object.values(st.players))if(o.team===p.team&&o.alive)a.push(o);return a;}

// ===== PARTIDA =====
let game=null, cam={x:0,y:0}, lastKills={};
function startMatch(){
  inGame=true;
  ['menu','joinScreen','lobby'].forEach(s=>$(s).style.display='none');
  $('hud').style.display='block';
  if(offline) setInterval(()=>{if(!game||!game.over)offlineTick();},33);
  else setInterval(()=>{if(socket&&inGame)socket.emit('input',myInput);},33);
  requestAnimationFrame(loop);
}
function endGame(d){
  inGame=false;
  const won = d.winner===(game?.players?.[myId]?.team||'blue');
  if(won){prog.trophies+=8;prog.coins+=25;}else{prog.trophies=Math.max(0,prog.trophies-5);prog.coins+=10;}
  saveProg();
  $('goTitle').textContent=won?'🏆 VITÓRIA!':'💀 DERROTA';
  $('goTitle').style.color=won?'#4ade80':'#f87171';
  $('goSub').textContent=`Placar: ${d.blue} x ${d.orange} · ${won?'+8 troféus':'-5 troféus'} · +${won?25:10} moedas`;
  $('gameover').style.display='flex';
}

// ===== RENDER =====
function loop(){
  if(!inGame)return;
  render();
  updateHUD();
  requestAnimationFrame(loop);
}
function render(){
  if(!game||!game.players)return;
  const me=game.players[myId];
  const map=MAPS[game.mapIdx||mapIdx||0];
  // câmera
  const tx=me?me.x:800, ty=me?me.y:600;
  cam.x+=((W/2-tx)-cam.x)*.15; cam.y+=((H/2-ty)-cam.y)*.15;
  ctx.fillStyle=map.bg; ctx.fillRect(0,0,W,H);
  ctx.save(); ctx.translate(cam.x,cam.y);
  // chão texturizado
  ctx.fillStyle='rgba(255,255,255,.03)';
  for(let x=0;x<ARENA.w;x+=80)for(let y=0;y<ARENA.h;y+=80)if((x+y)%160===0)ctx.fillRect(x,y,80,80);
  // arbustos
  if(game.bushes)for(const b of game.bushes){ctx.fillStyle='rgba(34,197,94,.25)';ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,7);ctx.fill();}
  // poças
  if(game.puddles)for(const p of game.puddles){ctx.fillStyle='rgba(244,114,182,.35)';ctx.beginPath();ctx.arc(p.x,p.y,50,0,7);ctx.fill();}
  // paredes
  for(const w of map.walls){const g=ctx.createLinearGradient(w.x,w.y,w.x,w.y+w.h);g.addColorStop(0,'#475569');g.addColorStop(1,'#1e293b');ctx.fillStyle=g;ctx.fillRect(w.x,w.y,w.w,w.h);ctx.strokeStyle='#0f172a';ctx.lineWidth=3;ctx.strokeRect(w.x,w.y,w.w,w.h);}
  // powerups
  if(game.powerups)for(const p of game.powerups){if(p.taken)continue;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(performance.now()*.002);ctx.fillStyle=p.type==='heal'?'#22c55e':p.type==='dmg'?'#ef4444':'#3b82f6';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=12;ctx.fillRect(-10,-10,20,20);ctx.restore();}
  // gemas
  if(game.gems)for(const g of game.gems){if(g.taken)continue;ctx.save();ctx.translate(g.x,g.y+Math.sin(performance.now()*.005)*5);ctx.fillStyle='#22d3ee';ctx.shadowColor='#22d3ee';ctx.shadowBlur=15;ctx.beginPath();ctx.moveTo(0,-14);ctx.lineTo(12,0);ctx.lineTo(0,14);ctx.lineTo(-12,0);ctx.closePath();ctx.fill();ctx.restore();}
  // bola
  if(game.mode==='brawlball'&&game.ball&&!game.ballCarrier){ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(game.ball.x,game.ball.y,16,0,7);ctx.fill();ctx.strokeStyle='#000';ctx.lineWidth=2;ctx.stroke();}
  // gols
  if(game.mode==='brawlball'){ctx.fillStyle='rgba(96,165,250,.3)';ctx.fillRect(0,500,30,200);ctx.fillStyle='rgba(251,146,60,.3)';ctx.fillRect(ARENA.w-30,500,30,200);}
  // cofres (heist)
  if(game.mode==='heist'){drawSafe(150,600,game.safeBlue,'#60a5fa');drawSafe(1450,600,game.safeOrange,'#fb923c');}
  // balas
  if(game.bullets)for(const b of game.bullets){ctx.fillStyle=BIBOS[b.bibo]?.color||'#fff';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=8;ctx.beginPath();ctx.arc(b.x,b.y,5,0,7);ctx.fill();ctx.shadowBlur=0;}
  // minions
  if(game.minions)for(const m of game.minions){ctx.fillStyle=m.color||'#78350f';ctx.beginPath();ctx.arc(m.x,m.y,m.size||10,0,7);ctx.fill();}
  // jogadores
  for(const p of Object.values(game.players)){
    if(!p.alive)continue;
    if(p.invisible>0 && p.id!==myId){ctx.globalAlpha=.25;}
    if(p.invuln>0){ctx.strokeStyle='rgba(255,255,255,.6)';ctx.lineWidth=3;ctx.beginPath();ctx.arc(p.x,p.y,30,0,7);ctx.stroke();}
    drawBibo(ctx,p.bibo,p.x,p.y,p.angle||0,performance.now()/1000,{stun:p.stun,slow:p.slow,poison:p.poison,invuln:p.invuln,flying:p.flying,rolling:p.rolling,shield:p.shield});
    ctx.globalAlpha=1;
    // barra de vida
    const bw=44; ctx.fillStyle='#000a';ctx.fillRect(p.x-bw/2,p.y-38,bw,6);
    ctx.fillStyle=p.team==='blue'?'#60a5fa':'#fb923c';ctx.fillRect(p.x-bw/2,p.y-38,bw*(p.hp/p.maxhp),6);
    // nome
    ctx.fillStyle='#fff';ctx.font='10px sans-serif';ctx.textAlign='center';ctx.fillText(p.nick,p.x,p.y-44);
    if(p.hasBall){ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(p.x,p.y-50,8,0,7);ctx.fill();}
    if(p.gems>0){ctx.fillStyle='#22d3ee';ctx.font='bold 11px sans-serif';ctx.fillText('💎'+p.gems,p.x,p.y-56);}
    if(p.superCharge>=100){ctx.strokeStyle='#facc15';ctx.lineWidth=2;ctx.beginPath();ctx.arc(p.x,p.y,28,0,7);ctx.stroke();}
  }
  // efeitos (anéis)
  if(game.effects)for(const e of game.effects){if(e.type==='ring'){ctx.globalAlpha=Math.max(0,e.t*2);ctx.strokeStyle=e.color;ctx.lineWidth=4;ctx.beginPath();ctx.arc(e.x,e.y,e.r,0,7);ctx.stroke();ctx.globalAlpha=1;}}
  ctx.restore();
  // minimapa
  drawMinimap();
}
function drawSafe(x,y,hp,color){const w=60;ctx.fillStyle='#78350f';ctx.fillRect(x-w/2,y-w/2,w,w);ctx.fillStyle=color;ctx.fillRect(x-w/2,y-w/2,w*(hp.hp/hp.maxhp),8);ctx.strokeStyle='#000';ctx.lineWidth=3;ctx.strokeRect(x-w/2,y-w/2,w,w);}
function drawMinimap(){
  const c=$('minimap'),x=c.getContext('2d');x.clearRect(0,0,120,90);x.fillStyle='#0006';x.fillRect(0,0,120,90);
  const sx=120/ARENA.w,sy=90/ARENA.h;
  if(!game||!game.players)return;
  for(const p of Object.values(game.players)){if(!p.alive)continue;x.fillStyle=p.team==='blue'?'#60a5fa':'#fb923c';x.beginPath();x.arc(p.x*sx,p.y*sy,p.id===myId?4:2.5,0,7);x.fill();}
}
// ===== DESENHO DOS 12 BIBOS (Canvas rico) =====
function drawBibo(ctx,bid,x,y,angle,t,fx){
  const b=BIBOS[bid], s=22;
  ctx.save(); ctx.translate(x,y);
  if(fx?.stun>0){ctx.save();ctx.translate((Math.random()-.5)*3,(Math.random()-.5)*3);}
  const flutter=Math.sin(t*25)*.5, wig=Math.sin(t*8)*.15;
  const gloss=(gx,gy,gr)=>{ctx.fillStyle='rgba(255,255,255,.35)';ctx.beginPath();ctx.arc(gx,gy,gr,0,7);ctx.fill();};
  const bodyGrad=ctx.createRadialGradient(-s*.3,-s*.3,s*.2,0,0,s);
  bodyGrad.addColorStop(0,b.color);bodyGrad.addColorStop(1,shade(b.color,-40));
  ctx.fillStyle=bodyGrad;
  ctx.rotate(angle);
  switch(bid){
    case 0:{ // sapo
      ctx.beginPath();ctx.ellipse(0,0,s,s*.85,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,-30);for(const sx2 of[-s*.5,s*.5]){ctx.beginPath();ctx.arc(sx2,-s*.7,s*.35,0,7);ctx.fill();}
      ctx.fillStyle='#fff';for(const sx2 of[-s*.5,s*.5]){ctx.beginPath();ctx.arc(sx2,-s*.7,s*.2,0,7);ctx.fill();}
      ctx.fillStyle='#000';for(const sx2 of[-s*.45,s*.55]){ctx.beginPath();ctx.arc(sx2,-s*.7,s*.1,0,7);ctx.fill();}
      gloss(-s*.3,-s*.4,s*.25);
      ctx.strokeStyle='#ff6b9d';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(s*.5,s*.2);ctx.quadraticCurveTo(s*1.2,s*.4+Math.sin(t*10)*3,s*1.5,s*.3);ctx.stroke();
      break;}
    case 1:{ // barata
      ctx.beginPath();ctx.ellipse(0,0,s,s*.7,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,30);ctx.beginPath();ctx.ellipse(-s*.2,0,s*.5,s*.55,0,0,7);ctx.fill();
      ctx.strokeStyle=shade(b.color,-30);ctx.lineWidth=2;
      for(let i=0;i<3;i++){const ly=-s*.5+i*s*.5;const lp=Math.sin(t*15+i)*3;
        ctx.beginPath();ctx.moveTo(-s*.3,ly);ctx.lineTo(-s*1.1,ly+lp);ctx.moveTo(s*.3,ly);ctx.lineTo(s*1.1,ly-lp);ctx.stroke();}
      ctx.strokeStyle='#333';ctx.beginPath();ctx.moveTo(s*.6,-s*.4);ctx.lineTo(s*1.4,-s*.9+wig*5);ctx.moveTo(s*.6,s*.4);ctx.lineTo(s*1.4,s*.9-wig*5);ctx.stroke();
      ctx.fillStyle='#ff0';ctx.beginPath();ctx.arc(s*.5,-s*.25,3,0,7);ctx.arc(s*.5,s*.25,3,0,7);ctx.fill();
      gloss(-s*.3,-s*.3,s*.2);
      break;}
    case 2:{ // rato
      ctx.beginPath();ctx.ellipse(0,0,s*.9,s*.7,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,20);ctx.beginPath();ctx.ellipse(s*.5,0,s*.5,s*.45,0,0,7);ctx.fill();
      ctx.fillStyle='#fbcfe8';ctx.beginPath();ctx.arc(s*.2,-s*.7,s*.3,0,7);ctx.arc(s*.2,s*.7,s*.3,0,7);ctx.fill();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.8,-s*.15,2.5,0,7);ctx.arc(s*.8,s*.15,2.5,0,7);ctx.fill();
      ctx.strokeStyle='#fda4af';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-s*.8,0);ctx.quadraticCurveTo(-s*1.5,Math.sin(t*5)*8,-s*1.8,0);ctx.stroke();
      gloss(-s*.2,-s*.3,s*.2);
      break;}
    case 3:{ // lagartixa
      ctx.beginPath();ctx.ellipse(0,0,s,s*.6,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,-20);ctx.beginPath();ctx.ellipse(s*.6,0,s*.45,s*.4,0,0,7);ctx.fill();
      ctx.strokeStyle=shade(b.color,-30);ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-s*.8,0);ctx.quadraticCurveTo(-s*1.5,wig*10,-s*1.8,wig*5);ctx.stroke();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.85,-s*.15,2.5,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,30);for(const [lx,ly]of[[-.3,-.6],[-.3,.6],[.3,-.6],[.3,.6]]){ctx.beginPath();ctx.arc(lx*s,ly*s,3,0,7);ctx.fill();}
      gloss(-s*.2,-s*.25,s*.2);
      break;}
    case 4:{ // lesma
      ctx.fillStyle='#fda4af';ctx.beginPath();ctx.ellipse(-s*.3,s*.3,s*.8,s*.4,0,0,7);ctx.fill();
      ctx.fillStyle='#fbbf24';ctx.beginPath();ctx.arc(-s*.2,-s*.2,s*.75,0,7);ctx.fill();
      ctx.strokeStyle='#b45309';ctx.lineWidth=2;ctx.beginPath();for(let a=0;a<5.5;a+=.3){const r=a*3;ctx.lineTo(-s*.2+Math.cos(a+t*.5)*r,-s*.2+Math.sin(a+t*.5)*r);}ctx.stroke();
      ctx.strokeStyle='#fda4af';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(s*.5,-s*.1);ctx.lineTo(s*.9,-s*.6+wig*3);ctx.moveTo(s*.5,s*.1);ctx.lineTo(s*.9,s*.6-wig*3);ctx.stroke();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.9,-s*.6,2.5,0,7);ctx.arc(s*.9,s*.6,2.5,0,7);ctx.fill();
      break;}
    case 5:{ // aranha
      ctx.beginPath();ctx.arc(0,0,s*.7,0,7);ctx.fill();
      ctx.strokeStyle=shade(b.color,-30);ctx.lineWidth=2.5;
      for(let i=0;i<4;i++){const a=(i/4)*.8-.4;const lp=Math.sin(t*12+i)*4;
        ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(-s*.5,(i-1.5)*s*.5,-s*1.2,(i-1.5)*s*.6+lp);ctx.moveTo(0,0);ctx.quadraticCurveTo(s*.5,(i-1.5)*s*.5,s*1.2,(i-1.5)*s*.6-lp);ctx.stroke();}
      ctx.fillStyle='#ef4444';ctx.shadowColor='#ef4444';ctx.shadowBlur=6;
      for(const [ex,ey]of[[s*.3,-s*.25],[s*.3,s*.25],[s*.5,-s*.1],[s*.5,s*.1]]){ctx.beginPath();ctx.arc(ex*s,ey*s,2.5,0,7);ctx.fill();}
      ctx.shadowBlur=0; gloss(-s*.2,-s*.2,s*.2);
      break;}
    case 6:{ // grilo
      ctx.beginPath();ctx.ellipse(0,0,s*.8,s*.55,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,20);ctx.beginPath();ctx.ellipse(s*.5,0,s*.4,s*.35,0,0,7);ctx.fill();
      ctx.strokeStyle=shade(b.color,-20);ctx.lineWidth=3;
      ctx.beginPath();ctx.moveTo(-s*.5,s*.3);ctx.lineTo(-s*1.2,s*.9);ctx.moveTo(-s*.5,-s*.3);ctx.lineTo(-s*1.2,-s*.9);ctx.stroke();
      ctx.fillStyle='rgba(255,255,255,.3)';ctx.beginPath();ctx.ellipse(0,-s*.4+flutter*2,s*.7,s*.25,-.3,0,7);ctx.fill();
      ctx.strokeStyle='#333';ctx.beginPath();ctx.moveTo(s*.7,-s*.15);ctx.lineTo(s*1.5,-s*.5+wig*4);ctx.moveTo(s*.7,s*.15);ctx.lineTo(s*1.5,s*.5-wig*4);ctx.stroke();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.75,-s*.1,2,0,7);ctx.fill();
      break;}
    case 7:{ // formiga
      ctx.fillStyle=bodyGrad;
      ctx.beginPath();ctx.arc(-s*.6,0,s*.4,0,7);ctx.fill();
      ctx.beginPath();ctx.arc(0,0,s*.35,0,7);ctx.fill();
      ctx.beginPath();ctx.arc(s*.6,0,s*.45,0,7);ctx.fill();
      ctx.strokeStyle=shade(b.color,-30);ctx.lineWidth=1.5;
      for(let i=0;i<3;i++){const ly=-.3+i*.3;const lp=Math.sin(t*14+i)*2;ctx.beginPath();ctx.moveTo(0,ly*s);ctx.lineTo(-s*.6,(ly*s)+lp+3);ctx.moveTo(0,ly*s);ctx.lineTo(s*.6,(ly*s)-lp-3);ctx.stroke();}
      ctx.strokeStyle='#000';ctx.beginPath();ctx.moveTo(s*.9,-s*.15);ctx.lineTo(s*1.3,-s*.4);ctx.moveTo(s*.9,s*.15);ctx.lineTo(s*1.3,s*.4);ctx.stroke();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.85,-s*.1,2,0,7);ctx.arc(s*.85,s*.1,2,0,7);ctx.fill();
      break;}
    case 8:{ // minhoca
      for(let i=5;i>=0;i--){const seg=5-i;ctx.fillStyle=shade(b.color,seg*6-15);ctx.beginPath();ctx.arc(-i*s*.32,Math.sin(t*6+i*.8)*4,s*.32,0,7);ctx.fill();}
      ctx.fillStyle=shade(b.color,10);ctx.beginPath();ctx.arc(s*.3,0,s*.4,0,7);ctx.fill();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.5,-s*.12,2.5,0,7);ctx.arc(s*.5,s*.12,2.5,0,7);ctx.fill();
      ctx.strokeStyle='#65a30d';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(s*.6,-s*.25);ctx.lineTo(s*.9,-s*.5);ctx.moveTo(s*.6,s*.25);ctx.lineTo(s*.9,s*.5);ctx.stroke();
      break;}
    case 9:{ // escorpião
      ctx.beginPath();ctx.ellipse(0,0,s*.8,s*.55,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,-20);ctx.beginPath();ctx.ellipse(s*.5,0,s*.4,s*.35,0,0,7);ctx.fill();
      ctx.strokeStyle=shade(b.color,-30);ctx.lineWidth=3;
      ctx.beginPath();ctx.moveTo(-s*.6,0);ctx.quadraticCurveTo(-s*1.2,-s*.8,-s*.8,-s*1.1);ctx.stroke();
      ctx.fillStyle='#fbbf24';ctx.shadowColor='#fbbf24';ctx.shadowBlur=8;ctx.beginPath();ctx.arc(-s*.8,-s*1.1+Math.sin(t*6)*2,4,0,7);ctx.fill();ctx.shadowBlur=0;
      ctx.strokeStyle=shade(b.color,-30);ctx.lineWidth=2.5;ctx.beginPath();ctx.moveTo(s*.7,-s*.2);ctx.lineTo(s*1.2,-s*.5);ctx.moveTo(s*.7,s*.2);ctx.lineTo(s*1.2,s*.5);ctx.stroke();
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.75,-s*.1,2,0,7);ctx.fill();
      gloss(-s*.2,-s*.2,s*.2);
      break;}
    case 10:{ // joaninha
      ctx.fillStyle='#ef4444';ctx.beginPath();ctx.arc(0,0,s,0,7);ctx.fill();
      ctx.fillStyle='#000';ctx.fillRect(-1.5,-s,3,s*2);
      ctx.fillStyle='#000';for(const [px,py]of[[-s*.4,-s*.4],[s*.4,-s*.4],[-s*.4,s*.4],[s*.4,s*.4],[0,0]]){ctx.beginPath();ctx.arc(px,py,s*.15,0,7);ctx.fill();}
      ctx.fillStyle='#000';ctx.beginPath();ctx.arc(s*.7,0,s*.35,0,7);ctx.fill();
      ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(s*.8,-s*.1,2,0,7);ctx.fill();
      ctx.fillStyle='rgba(255,255,255,.4)';ctx.beginPath();ctx.ellipse(-s*.3,-s*.5+flutter*2,s*.5,s*.2,-.4,0,7);ctx.fill();
      break;}
    case 11:{ // mosquito
      ctx.beginPath();ctx.ellipse(0,0,s*.5,s*.35,0,0,7);ctx.fill();
      ctx.fillStyle=shade(b.color,20);ctx.beginPath();ctx.ellipse(s*.5,0,s*.35,s*.3,0,0,7);ctx.fill();
      ctx.fillStyle='rgba(200,220,255,.4)';ctx.beginPath();ctx.ellipse(-s*.2,-s*.5+flutter*4,s*.6,s*.25,-.3,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(-s*.2,s*.5-flutter*4,s*.6,s*.25,.3,0,7);ctx.fill();
      ctx.fillStyle='#ef4444';ctx.shadowColor='#ef4444';ctx.shadowBlur=8;ctx.beginPath();ctx.arc(s*.6,-s*.12,3,0,7);ctx.arc(s*.6,s*.12,3,0,7);ctx.fill();ctx.shadowBlur=0;
      ctx.strokeStyle='#94a3b8';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(s*.8,0);ctx.lineTo(s*1.4,0);ctx.stroke();
      ctx.strokeStyle='#64748b';ctx.beginPath();for(let i=0;i<3;i++){ctx.moveTo(-s*.3+i*s*.3,-s*.4);ctx.lineTo(-s*.5+i*s*.3,-s*.9);ctx.moveTo(-s*.3+i*s*.3,s*.4);ctx.lineTo(-s*.5+i*s*.3,s*.9);}ctx.stroke();
      break;}
  }
  if(fx?.stun>0){ctx.restore();ctx.fillStyle='#facc15';ctx.font='14px sans-serif';ctx.textAlign='center';ctx.fillText('💫',0,-s-8);}
  if(fx?.poison>0){ctx.fillStyle='rgba(132,204,22,.5)';ctx.beginPath();ctx.arc((Math.random()-.5)*s,(Math.random()-.5)*s,3,0,7);ctx.fill();}
  if(fx?.shield>0){ctx.strokeStyle='rgba(96,165,250,.7)';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,s+6,0,7);ctx.stroke();}
  ctx.restore();
}
function shade(hex,amt){const n=parseInt(hex.slice(1),16);let r=(n>>16)+amt,g=((n>>8)&255)+amt,b=(n&255)+amt;r=Math.max(0,Math.min(255,r));g=Math.max(0,Math.min(255,g));b=Math.max(0,Math.min(255,b));return`rgb(${r},${g},${b})`;}

// ===== HUD =====
function updateHUD(){
  if(!game||!game.players)return;
  const me=game.players[myId]; if(!me)return;
  $('hpFill').style.width=Math.max(0,(me.hp/me.maxhp)*100)+'%';
  $('superFill').style.width=(me.superCharge||0)+'%';
  $('superReady').style.display=me.superCharge>=100?'block':'none';
  $('superBtn').classList.toggle('ready',me.superCharge>=100);
  $('gadgetCharges').textContent=me.gadgetCharges||0;
  $('gadgetBtn').style.opacity=(me.gadgetCharges>0&&(me.gadgetCd||0)<=0)?1:.4;
  const m=Math.floor(Math.max(0,game.t)/60), s=Math.floor(Math.max(0,game.t)%60);
  $('timer').textContent=`${m}:${s.toString().padStart(2,'0')}`;
  if(game.mode==='gemgrab'){$('blueScore').textContent='💎'+(game.gemsBlue||0);$('orangeScore').textContent='💎'+(game.gemsOrange||0);}
  else if(game.mode==='bounty'){let bs=0,os=0;for(const p of Object.values(game.players)){if(p.team==='blue')bs+=p.stars||0;else os+=p.stars||0;}$('blueScore').textContent='⭐'+bs;$('orangeScore').textContent='⭐'+os;}
  else{$('blueScore').textContent=game.blueScore||0;$('orangeScore').textContent=game.orangeScore||0;}
  $('progBar').textContent=`🏆${prog.trophies} 🪙${prog.coins}`;
  $('progBar').style.display='block';
}
