# 🐛 BIBOS BRAWL 🪳

Multiplayer 3v3 estilo Brawl Stars com 12 bichinhos (bibos), 5 modos de jogo, bots preenchendo vagas e modo treino offline.

## 🚀 Como rodar (com amigos à distância)

### Opção A — Rodar localmente (mesma rede Wi-Fi)
```bash
npm install
npm start
```
Abra `http://localhost:3000` no navegador. Amigos na mesma rede entram pelo seu IP local (`http://SEU_IP:3000`).

### Opção B — Hospedar grátis na internet (Render / Replit / Railway)
1. Suba esta pasta para um repositório no GitHub.
2. No [Render.com](https://render.com) → New → Web Service → conecte o repo → comando `npm install && npm start` → porta `3000`.
3. Compartilhe a URL (ex: `https://seu-jogo.onrender.com`) com os amigos. Um cria sala, recebe o código de 6 dígitos, os outros entram.

> Dica: no Render plano grátis o servidor "dorme" após inatividade — a primeira entrada demora ~30s para acordar.

### Opção C — Modo TREINO offline (sem servidor, sem internet)
Abra o arquivo `public/index.html` direto no navegador (dê dois cliques). Escolha "🤖 Treino Offline" e jogue contra bots (3 dificuldades). Não precisa de servidor nem internet.

## 🎮 Controles
- **Celular**: joystick esquerdo = mover · direito = mirar/atirar · botões SUPER e GADGET à direita.
- **PC**: WASD = mover · mouse = mirar · clique/espaço = atirar · Q = SUPER · E = GADGET.

## 🐜 12 Bibos
Sapo, Barata, Rato, Lagartixa, Lesma, Aranha, Grilo, Formiga, Minhoca, Escorpião, Joaninha, Mosquito — cada um com Ataque, SUPER, Gadget (2 cargas) e Passiva únicos.

## 🏆 Modos
Gem Grab (3v3), Showdown (battle royale 6), Brawl Ball (futebol), Heist (cofre), Bounty (estrelas) + Laboratório (treino com bots).

Progresso (troféus, moedas, bibos desbloqueados, níveis) salvo no navegador (localStorage).
