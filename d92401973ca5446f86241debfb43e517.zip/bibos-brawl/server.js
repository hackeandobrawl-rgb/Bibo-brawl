// BIBOS BRAWL — servidor (Express + Socket.IO)
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(path.join(__dirname, 'public')));
const PORT = process.env.PORT || 3000;

// ============ 12 BIBOS ============
// attack: 'shot'|'spread'|'melee'|'aoe'|'pierce'|'rapid'|'shotgun'
const BIBOS = [
  {id:0, name:'Zapos', ico:'🐸', color:'#4ade80', hp:7200, speed:170, dmg:900, rate:0.9, bullets:1, spread:0.12, bspeed:520, range:380, attack:'aoe', aoeRadius:70, superName:'Salto Monumental', gadgetName:'Língua Pegajosa', passive:'Pele Venenosa'},
  {id:1, name:'Barata Baba', ico:'🪳', color:'#a16207', hp:4800, speed:260, dmg:700, rate:0.25, bullets:1, spread:0.15, bspeed:620, range:260, attack:'melee', meleeRange:60, superName:'Sobrevivente', gadgetName:'Exoesqueleto', passive:'Imune a Veneno'},
  {id:2, name:'Ratatuili', ico:'🐁', color:'#94a3b8', hp:5400, speed:210, dmg:1100, rate:0.8, bullets:1, spread:0.1, bspeed:560, range:400, attack:'aoe', aoeRadius:55, superName:'Toqueia', gadgetName:'Rato de Borracha', passive:'Pés Leves'},
  {id:3, name:'Largatixa Goat', ico:'🦎', color:'#22d3ee', hp:5600, speed:190, dmg:800, rate:0.7, bullets:1, spread:0.1, bspeed:540, range:420, attack:'shot', stunOnHit:1.0, superName:'Cauda Falsa', gadgetName:'Parede de Vidro', passive:'Regeneração'},
  {id:4, name:'Besba', ico:'🐌', color:'#f472b6', hp:9000, speed:110, dmg:700, rate:1.0, bullets:1, spread:0.1, bspeed:460, range:380, attack:'puddle', puddleDur:3, superName:'Concha Gigante', gadgetName:'Babada Turbo', passive:'Concha Dura'},
  {id:5, name:'Babanha', ico:'🕷️', color:'#a78bfa', hp:5200, speed:175, dmg:850, rate:0.6, bullets:1, spread:0.1, bspeed:540, range:440, attack:'shot', slowOnHit:1.5, superName:'Teia de Captura', gadgetName:'Fio de Seda', passive:'Sensibilidade'},
  {id:6, name:'Bribo', ico:'🦗', color:'#84cc16', hp:5000, speed:205, dmg:750, rate:0.5, bullets:1, spread:0.08, bspeed:600, range:480, attack:'ricochet', superName:'Grito Sônico', gadgetName:'Pulo de Grilo', passive:'Pernas Saltadoras'},
  {id:7, name:'Pocket Ants', ico:'🐜', color:'#78350f', hp:6000, speed:185, dmg:1000, rate:0.6, bullets:1, spread:0.1, bspeed:560, range:300, attack:'melee', meleeRange:55, superName:'Enxame', gadgetName:'Folha de Formiga', passive:'Força de Formiga'},
  {id:8, name:'Binhobo', ico:'🐛', color:'#a3e635', hp:5800, speed:180, dmg:800, rate:0.65, bullets:1, spread:0.1, bspeed:540, range:360, attack:'shot', blindOnHit:1.2, superName:'Terremoto', gadgetName:'Túnel Rápido', passive:'Regeneração na Terra'},
  {id:9, name:'Besborbião', ico:'🦂', color:'#dc2626', hp:6400, speed:165, dmg:1300, rate:0.85, bullets:1, spread:0.06, bspeed:520, range:280, attack:'pierce', poisonOnHit:3, superName:'Ferrão Venenoso', gadgetName:'Armadura de Quitina', passive:'Cauda de Aço'},
  {id:10, name:'Buabinha', ico:'🐞', color:'#ef4444', hp:5200, speed:195, dmg:500, rate:0.55, bullets:5, spread:0.45, bspeed:580, range:360, attack:'shotgun', critChance:0.2, superName:'Enxame da Sorte', gadgetName:'Asa de Joaninha', passive:'Sorte'},
  {id:11, name:'Bizu', ico:'🦟', color:'#64748b', hp:4600, speed:240, dmg:650, rate:0.35, bullets:1, spread:0.12, bspeed:660, range:340, attack:'rapid', lifesteal:true, superName:'Praga', gadgetName:'Zumbido', passive:'Voo'},
];

// ============ MAPAS (paredes) ============
const MAPS = [
  {name:'Jardim das Gemas', bg:'#1a3a2a', walls:[{x:350,y:250,w:160,h:35},{x:350,y:250,w:35,h:160},{x:1090,y:250,w:160,h:35},{x:1215,y:250,w:35,h:160},{x:350,y:915,w:160,h:35},{x:350,y:860,w:35,h:160},{x:1090,y:915,w:160,h:35},{x:1215,y:860,w:35,h:160},{x:750,y:500,w:100,h:200},{x:200,y:550,w:35,h:140},{x:1365,y:550,w:35,h:140},{x:600,y:180,w:140,h:30},{x:860,y:180,w:140,h:30},{x:600,y:990,w:140,h:30},{x:860,y:990,w:140,h:30}]},
  {name:'Lata de Lixo', bg:'#2a2520', walls:[{x:100,y:300,w:300,h:35},{x:1200,y:300,w:300,h:35},{x:100,y:865,w:300,h:35},{x:1200,y:865,w:300,h:35},{x:400,y:300,w:35,h:250},{x:1165,y:300,w:35,h:250},{x:400,y:650,w:35,h:250},{x:1165,y:650,w:35,h:250},{x:700,y:200,w:200,h:35},{x:700,y:965,w:200,h:35},{x:300,y:550,w:140,h:35},{x:1160,y:550,w:140,h:35},{x:750,y:550,w:100,h:100}]},
  {name:'Campo de Futebol', bg:'#14532d', walls:[{x:0,y:500,w:1600,h:30},{x:700,y:0,w:200,h:150},{x:700,y:1050,w:200,h:150},{x:300,y:300,w:120,h:30},{x:1180,y:300,w:120,h:30},{x:300,y:870,w:120,h:30},{x:1180,y:870,w:120,h:30}]},
  {name:'Formigueiro', bg:'#3a2510', walls:[{x:250,y:200,w:120,h:120},{x:1230,y:200,w:120,h:120},{x:250,y:880,w:120,h:120},{x:1230,y:880,w:120,h:120},{x:700,y:450,w:200,h:30},{x:700,y:720,w:200,h:30},{x:500,y:300,w:30,h:150},{x:1070,y:300,w:30,h:150},{x:500,y:750,w:30,h:150},{x:1070,y:750,w:30,h:150}]},
  {name:'Praça das Estrelas', bg:'#1e2a4a', walls:[{x:400,y:400,w:200,h:30},{x:1000,y:400,w:200,h:30},{x:400,y:770,w:200,h:30},{x:1000,y:770,w:200,h:30},{x:750,y:250,w:100,h:100},{x:750,y:850,w:100,h:100},{x:150,y:600,w:30,h:150},{x:1420,y:600,w:30,h:150}]},
];
const ARENA = {w:1600,h:1200};
const TICK = 1000/30;

// ============ SALAS ============
const rooms = {}; // code -> room state
function randCode(){ const L='ABCDEFGHJKLMNPQRSTUVWXYZ0123456789'; let s=''; for(let i=0;i<6;i++) s+=L[Math.floor(Math.random()*L.length)]; return s; }

function newRoom(code, mode, mapIdx){
  return {code, mode, mapIdx, players:{}, sockets:{}, bots:[], state:makeState(mode,mapIdx), started:false, tickHandle:null, blueScore:0, orangeScore:0, gemsBlue:0, gemsOrange:0, gemTimer:0, ball:{x:800,y:600,vx:0,vy:0}, safeBlue:{hp:15000,maxhp:15000}, safeOrange:{hp:15000,maxhp:15000}, showdownShrink:0, stars:{}, effects:[], particles:[]};
}
function makeState(mode,mapIdx){ return {t:mode==='showdown'?120:150, over:false, winner:null, bullets:[], minions:[], powerups:spawnPowerups(), gems:mode==='gemgrab'?[{x:800,y:600,taken:false}]:[], bushes:makeBushes(mapIdx)}; }
function spawnPowerups(){ const p=[]; for(let i=0;i<4;i++) p.push({x:200+Math.random()*1200,y:150+Math.random()*900,type:['heal','dmg','speed'][i%3],taken:false}); return p; }
function makeBushes(mapIdx){ const b=[]; for(let i=0;i<6;i++) b.push({x:250+((i*269)%1100), y:200+((i*431)%800), r:60}); return b; }

function collidesWall(x,y,r,mapIdx){ for(const w of MAPS[mapIdx].walls) if(x>w.x-r&&x<w.x+w.w+r&&y>w.y-r&&y<w.y+w.h+r) return true; return false; }

// ============ BOT AI ============
const BOT_NAMES=['BotZika','NoobMaster','SniperBR','XxKillxX','Falcão','Trovão','Matador77','Lagartixa','Venenoso','ProGamer'];
function makeBot(team, slot){
  const bibo = Math.floor(Math.random()*12);
  return {id:'bot'+slot, nick:BOT_NAMES[slot%10]+Math.floor(Math.random()*99), bibo, team, isBot:true, x:team==='blue'?200+Math.random()*200:1200+Math.random()*200, y:300+Math.random()*600, hp:BIBOS[bibo].hp, maxhp:BIBOS[bibo].hp, alive:true, respawnAt:0, input:{mx:0,my:0,ax:1,ay:0,fire:false,super:false,gadget:false}, lastShot:0, superCharge:0, gadgetCharges:2, gadgetCd:0, stun:0, slow:0, poison:0, blind:0, shield:0, invisible:0, flying:0, intang:0, skill:0.7, strafeDir:Math.random()<0.5?1:-1, strafeT:0, thinkT:0, minions:0, stars:0, gems:0, hasBall:false, secondLife:false};
}
function botAI(bot, room, now){
  bot.thinkT -= 1/30;
  if(bot.thinkT<=0){
    bot.thinkT = 0.2+Math.random()*0.2;
    let nearest=null, nd=1e9;
    for(const p of Object.values(room.players)){ if(p.team===bot.team||!p.alive) continue; const d=Math.hypot(p.x-bot.x,p.y-bot.y); if(d<nd){nd=d;nearest=p;} }
    bot.target = nearest; bot.nd = nd;
  }
  const inp=bot.input, b=BIBOS[bot.bibo], t=bot.target;
  if(t && bot.nd<600){
    const ang=Math.atan2(t.y-bot.y,t.x-bot.x);
    const err=(Math.random()-0.5)*(1-bot.skill)*0.8;
    inp.ax=Math.cos(ang+err); inp.ay=Math.sin(ang+err);
    inp.fire = bot.nd < b.range*0.9 && Math.random()<(0.4+bot.skill*0.55);
    if(bot.superCharge>=100 && Math.random()<0.5) inp.super=true; else inp.super=false;
    const ideal=b.range*0.6;
    if(bot.nd>ideal){ inp.mx=Math.cos(ang)*0.8; inp.my=Math.sin(ang)*0.8; }
    else { bot.strafeT-=1/30; if(bot.strafeT<=0){bot.strafeT=0.6;bot.strafeDir*=-1;}
      inp.mx=Math.cos(ang+Math.PI/2)*bot.strafeDir; inp.my=Math.sin(ang+Math.PI/2)*bot.strafeDir; }
  } else { inp.mx=Math.sin(now*0.001+bot.id.length)*0.5; inp.my=Math.cos(now*0.0013)*0.5; inp.fire=false; inp.super=false; }
}

// ============ ENGINE ============
function spawnPlayer(p, team){
  const b=BIBOS[p.bibo];
  p.x = team==='blue' ? 150+Math.random()*150 : 1300+Math.random()*150;
  p.y = 300+Math.random()*600;
  p.hp=b.hp; p.maxhp=b.hp; p.alive=true; p.superCharge=Math.min(50,p.superCharge||0); p.gadgetCharges=2; p.stun=0; p.slow=0; p.poison=0; p.blind=0; p.shield=0; p.invisible=0; p.flying=0; p.intang=0; p.hasBall=false; p.minions=0;
}
function fireWeapon(p, room){
  const b=BIBOS[p.bibo];
  const a = p.angle||0;
  const n = b.bullets||1;
  for(let i=0;i<n;i++){
    const ang = a + (n>1 ? (i/(n-1)-0.5)*b.spread*2 : (Math.random()-0.5)*b.spread);
    room.state.bullets.push({x:p.x+Math.cos(ang)*25, y:p.y+Math.sin(ang)*25, vx:Math.cos(ang)*b.bspeed, vy:Math.sin(ang)*b.bspeed, dmg:b.dmg, owner:p.id, team:p.team, life:b.range/b.bspeed, bibo:p.bibo, hit:[], pierce:b.attack==='pierce', ricochet:b.attack==='ricochet', bounces:b.attack==='ricochet'?3:0, aoe:b.attack==='aoe'?b.aoeRadius:0, puddle:b.attack==='puddle', lifesteal:b.lifesteal, slow:b.slowOnHit||0, stun:b.stunOnHit||0, blind:b.blindOnHit||0, poison:b.poisonOnHit||0, crit:b.critChance||0});
  }
}
function activateSuper(p, room){
  if(p.superCharge<100) return;
  p.superCharge=0;
  const b=BIBOS[p.bibo];
  const a=p.angle||0;
  switch(p.bibo){
    case 0: // Sapo: salto (invulnerável + dano em área no pouso)
      p.invuln=0.8; p.flying=0.8; p.x+=Math.cos(a)*180; p.y+=Math.sin(a)*180;
      for(const e of allEnemies(p,room)){ if(Math.hypot(e.x-p.x,e.y-p.y)<150){ damage(e,1500,p,room); e.stun=Math.max(e.stun,1); } }
      room.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:150,color:b.color,t:0.5}); break;
    case 1: // Barata: segunda vida (flag)
      p.secondLife=true; break;
    case 2: // Rato: invisível + emboscada
      p.invisible=6; p.ambush=true; break;
    case 3: // Lagartixa: isca + invisível
      room.state.minions.push({x:p.x,y:p.y,vx:0,vy:0,hp:1500,maxhp:1500,dmg:0,life:5,owner:p.id,team:p.team,isDecoy:true,color:b.color,size:22});
      p.invisible=4; break;
    case 4: // Lesma: rola (invulnerável, destrói paredes, atropela)
      p.invuln=2.5; p.rolling=2.5; p.rollA=a; break;
    case 5: // Aranha: teia gigante (prende inimigos)
      for(const e of allEnemies(p,room)){ if(Math.hypot(e.x-p.x,e.y-p.y)<300){ e.stun=Math.max(e.stun,2); e.invisible=0; } }
      room.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:300,color:b.color,t:0.6}); break;
    case 6: // Grilo: grito sônico (empurra + atordoa)
      for(const e of allEnemies(p,room)){ const d=Math.hypot(e.x-p.x,e.y-p.y); if(d<350){ const ea=Math.atan2(e.y-p.y,e.x-p.x); e.x+=Math.cos(ea)*120; e.y+=Math.sin(ea)*120; if(d<150) e.stun=Math.max(e.stun,1.2); } }
      room.state.bullets=[]; break;
    case 7: // Formiga: enxame de minions
      for(let i=0;i<4;i++){ const ang=Math.random()*6.28; room.state.minions.push({x:p.x+Math.cos(ang)*40,y:p.y+Math.sin(ang)*40,vx:0,vy:0,hp:400,maxhp:400,dmg:600,life:8,owner:p.id,team:p.team,color:b.color,size:10,speed:180}); p.minions++; }
      break;
    case 8: // Minhoca: terremoto (enterra + emerge com dano)
      p.invuln=1.5; p.invisible=1.5; p.x+=Math.cos(a)*250; p.y+=Math.sin(a)*250;
      for(const e of allEnemies(p,room)){ if(Math.hypot(e.x-p.x,e.y-p.y)<160){ damage(e,1800,p,room); e.stun=Math.max(e.stun,1); } }
      room.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:160,color:b.color,t:0.5}); break;
    case 9: // Escorpião: ferrão venenoso (direcional)
      for(const e of allEnemies(p,room)){ const dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy); if(d<220&&Math.abs(Math.atan2(dy,dx)-a)<0.9){ damage(e,1200,p,room); e.poison=Math.max(e.poison,5); p.hp=Math.min(p.maxhp,p.hp+600); } }
      break;
    case 10: // Joaninha: cura aliados + velocidade
      for(const e of allAllies(p,room)){ e.hp=Math.min(e.maxhp,e.hp+1500); e.speedBoost=5; }
      room.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:250,color:'#f472b6',t:0.6}); break;
    case 11: // Mosquito: nuvem de mosquitos (drena vida)
      for(const e of allEnemies(p,room)){ if(Math.hypot(e.x-p.x,e.y-p.y)<280){ damage(e,1000,p,room); p.hp=Math.min(p.maxhp,p.hp+700); } }
      room.effects.push({type:'ring',x:p.x,y:p.y,r:0,max:280,color:'#64748b',t:0.6}); break;
  }
}
function useGadget(p, room){
  if(p.gadgetCharges<=0 || p.gadgetCd>0) return;
  p.gadgetCharges--; p.gadgetCd=20;
  const a=p.angle||0;
  switch(p.bibo){
    case 0: { // língua: puxa inimigo mais próximo
      let best=null,bd=1e9; for(const e of allEnemies(p,room)){const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<bd&&d<400){bd=d;best=e;}}
      if(best){const ea=Math.atan2(p.y-best.y,p.x-best.x);best.x+=Math.cos(ea)*120;best.y+=Math.sin(ea)*120;} break;}
    case 1: p.shield=Math.max(p.shield, p.maxhp*0.4); break; // escudo
    case 2: p.x+=Math.cos(a)*150; p.y+=Math.sin(a)*150; break; // dash através de parede
    case 3: p.flying=Math.max(p.flying,3); break; // escala parede
    case 4: p.slowTrail=4; break; // rastro slime
    case 5: { // hookshot
      p.x+=Math.cos(a)*250; p.y+=Math.sin(a)*250; break;}
    case 6: p.x-=Math.cos(a)*120; p.y-=Math.sin(a)*120; break; // pulo pra trás
    case 7: p.shield=Math.max(p.shield,1200); break; // escudo absorve
    case 8: p.x=p.spawnX||p.x; p.y=p.spawnY||p.y; break; // teleporte
    case 9: p.reflectNext=true; break; // reflete projétil
    case 10: p.flying=Math.max(p.flying,3); break; // voa
    case 11: p.intang=Math.max(p.intang,1.5); break; // intangível
  }
}
function allEnemies(p,room){ const arr=[]; for(const o of Object.values(room.players)) if(o.team!==p.team&&o.alive) arr.push(o); return arr; }
function allAllies(p,room){ const arr=[]; for(const o of Object.values(room.players)) if(o.team===p.team&&o.alive) arr.push(o); return arr; }
function damage(target, amount, attacker, room){
  if(target.invuln>0 || target.intang>0) return;
  if(attacker && attacker.reflectNext){ attacker.reflectNext=false; return; }
  if(target.shield>0){ const s=Math.min(target.shield,amount); target.shield-=s; amount-=s; }
  // passiva lesma: 30% menos dano de projétil
  if(target.bibo===4 && attacker) amount*=0.7;
  // passiva joaninha: crítico
  if(attacker && BIBOS[attacker.bibo].critChance && Math.random()<BIBOS[attacker.bibo].critChance) amount*=2;
  target.hp-=amount;
  if(attacker){ attacker.superCharge=Math.min(100, attacker.superCharge+amount*0.008); }
  // passiva sapo: pele venenosa (toque)
  if(attacker && target.bibo===0 && Math.hypot(attacker.x-target.x, attacker.y-target.y)<60){ attacker.hp-=amount*0.15; }
  if(target.hp<=0) killPlayer(target, attacker, room);
}
function killPlayer(p, killer, room){
  if(!p.alive) return;
  // barata segunda vida
  if(p.bibo===1 && p.secondLife){ p.secondLife=false; p.hp=1; p.invuln=5; return; }
  p.alive=false; p.deaths=(p.deaths||0)+1; p.respawnAt=Date.now()/1000+4;
  if(killer){ killer.kills=(killer.kills||0)+1; killer.superCharge=Math.min(100,killer.superCharge+25);
    if(room.mode==='bounty'){ killer.stars=(killer.stars||0)+1+(p.stars||0); p.stars=0; }
    if(p.hasBall){ p.hasBall=false; room.ball.x=p.x; room.ball.y=p.y; room.ball.vx=0; room.ball.vy=0; }
    if(p.gems>0){ p.gems=0; room.state.gems.push({x:p.x,y:p.y,taken:false}); }
  }
  // powerup drop
  if(Math.random()<0.3) room.state.powerups.push({x:p.x,y:p.y,type:'heal',taken:false});
}

function tickRoom(room){
  const now=Date.now()/1000, dt=1/30;
  const st=room.state;
  st.t-=dt;
  // efeitos
  for(let i=room.effects.length-1;i>=0;i--){const e=room.effects[i];e.t-=dt;if(e.type==='ring')e.r+=e.max*dt*3;if(e.t<=0)room.effects.splice(i,1);}
  // powerups respawn
  if(st.powerups.every(p=>p.taken) && Math.random()<0.02) st.powerups.push({x:200+Math.random()*1200,y:150+Math.random()*900,type:['heal','dmg','speed'][Math.floor(Math.random()*3)],taken:false});
  // showdown shrink
  if(room.mode==='showdown'){ room.showdownShrink+=dt*3; }
  // bola (brawl ball)
  if(room.mode==='brawlball'){
    room.ball.x+=room.ball.vx*dt; room.ball.y+=room.ball.vy*dt;
    room.ball.vx*=0.98; room.ball.vy*=0.98;
    if(collidesWall(room.ball.x,room.ball.y,15,room.mapIdx)){room.ball.vx*=-0.6;room.ball.vy*=-0.6;}
    room.ball.x=Math.max(20,Math.min(ARENA.w-20,room.ball.x)); room.ball.y=Math.max(20,Math.min(ARENA.h-20,room.ball.y));
    // gol
    if(room.ball.x<40 && room.ball.y>500 && room.ball.y<700){ room.orangeScore++; resetBall(room); if(room.orangeScore>=2){st.over=true;st.winner='orange';} }
    if(room.ball.x>ARENA.w-40 && room.ball.y>500 && room.ball.y<700){ room.blueScore++; resetBall(room); if(room.blueScore>=2){st.over=true;st.winner='blue';} }
  }
  // gem grab timer
  if(room.mode==='gemgrab'){
    if(room.gemsBlue>=10){room.gemTimer+=dt; if(room.gemTimer>=15){st.over=true;st.winner='blue';}} else room.gemTimer=0;
    if(room.gemsOrange>=10){room.gemTimerO=(room.gemTimerO||0)+dt; if(room.gemTimerO>=15){st.over=true;st.winner='orange';}} else room.gemTimerO=0;
    if(st.gems.every(g=>g.taken)) st.gems.push({x:800,y:600,taken:false});
  }
  if(st.t<=0 && !st.over){
    // decide winner by mode
    if(room.mode==='bounty'){ let bs=0,os=0; for(const p of Object.values(room.players)){if(p.team==='blue')bs+=p.stars||0;else os+=p.stars||0;} st.winner=bs>=os?'blue':'orange'; }
    else if(room.mode==='heist'){ st.winner = room.safeBlue.hp<room.safeOrange.hp ? 'orange' : 'blue'; }
    else st.winner = room.blueScore>=room.orangeScore?'blue':'orange';
    st.over=true;
  }
  // jogadores
  for(const p of Object.values(room.players)){
    if(!p.alive){ if(now>p.respawnAt) spawnPlayer(p,p.team); continue; }
    if(p.isBot) botAI(p, room, now*1000);
    const b=BIBOS[p.bibo], inp=p.input||{mx:0,my:0,ax:1,ay:0,fire:false};
    // timers
    if(p.stun>0)p.stun-=dt; if(p.slow>0)p.slow-=dt; if(p.poison>0){p.hp-=80*dt;p.poison-=dt;if(p.hp<=0){killPlayer(p,null,room);continue;}}
    if(p.blind>0)p.blind-=dt; if(p.invuln>0)p.invuln-=dt; if(p.invisible>0)p.invisible-=dt; if(p.flying>0)p.flying-=dt; if(p.intang>0)p.intang-=dt; if(p.rolling>0)p.rolling-=dt; if(p.speedBoost>0)p.speedBoost-=dt; if(p.gadgetCd>0)p.gadgetCd-=dt;
    // passiva lagartixa: regenera
    if(p.bibo===3 && (p.lastHit||0)<now-5) p.hp=Math.min(p.maxhp,p.hp+200*dt);
    if(p.bibo===8) p.hp=Math.min(p.maxhp,p.hp+60*dt);
    // movimento
    if(p.stun<=0){
      let vx=inp.mx||0, vy=inp.my||0; const vl=Math.hypot(vx,vy); if(vl>0){vx/=vl;vy/=vl;}
      let spd=b.speed*(p.slow>0?0.4:1)*(p.speedBoost>0?1.3:1)*(p.rolling>0?2.2:1);
      // passiva barata: imune a slow
      if(p.bibo===1) spd=b.speed*(p.speedBoost>0?1.3:1);
      let nx=p.x+vx*spd*dt, ny=p.y+vy*spd*dt;
      const canFly=p.flying>0 || p.bibo===11;
      if(canFly||!collidesWall(nx,p.y,22,room.mapIdx)) p.x=Math.max(30,Math.min(ARENA.w-30,nx));
      if(canFly||!collidesWall(p.x,ny,22,room.mapIdx)) p.y=Math.max(30,Math.min(ARENA.h-30,ny));
      // lesma rolando destrói paredes (simples: dá dano em área)
      if(p.rolling>0){ for(const e of allEnemies(p,room)) if(Math.hypot(e.x-p.x,e.y-p.y)<40) damage(e,400,p,room); }
      // rastro slime da lesma gadget
      if(p.slowTrail>0){ p.slowTrail-=dt; for(const e of allEnemies(p,room)) if(Math.hypot(e.x-p.x,e.y-p.y)<50) e.slow=Math.max(e.slow,1); }
    }
    if(inp.ax||inp.ay) p.angle=Math.atan2(inp.ay,inp.ax);
    // powerup pickup
    for(const pu of st.powerups){ if(!pu.taken && Math.hypot(pu.x-p.x,pu.y-p.y)<30){ pu.taken=true; if(pu.type==='heal')p.hp=Math.min(p.maxhp,p.hp+1500); if(pu.type==='dmg')p.dmgBoost=5; if(pu.type==='speed')p.speedBoost=5; } }
    // gem pickup
    if(room.mode==='gemgrab') for(const g of st.gems){ if(!g.taken && Math.hypot(g.x-p.x,g.y-p.y)<30){ g.taken=true; p.gems=(p.gems||0)+1; if(p.team==='blue')room.gemsBlue++; else room.gemsOrange++; } }
    // bola pickup
    if(room.mode==='brawlball' && !room.ballCarrier && Math.hypot(room.ball.x-p.x,room.ball.y-p.y)<35){ p.hasBall=true; room.ballCarrier=p.id; }
    if(p.hasBall){ room.ball.x=p.x; room.ball.y=p.y; }
    // tiro
    const rate=b.rate*(p.dmgBoost>0?0.8:1);
    if(inp.fire && p.stun<=0 && now-p.lastShot>rate){ p.lastShot=now; fireWeapon(p,room); }
    // super
    if(inp.super){ activateSuper(p,room); inp.super=false; }
    if(inp.gadget){ useGadget(p,room); inp.gadget=false; }
    // rato emboscada: primeiro tiro após invisível causa dano massivo
    if(p.ambush && p.invisible<=0){ p.ambush=false; }
  }
  // minions
  for(let i=st.minions.length-1;i>=0;i--){
    const m=st.minions[i]; m.life-=dt;
    if(m.life<=0||m.hp<=0){ if(m.owner&&room.players[m.owner])room.players[m.owner].minions=Math.max(0,(room.players[m.owner].minions||1)-1); st.minions.splice(i,1); continue; }
    if(m.isDecoy) continue;
    let tgt=null,bd=1e9;
    for(const p of Object.values(room.players)){ if(p.team===m.team||!p.alive)continue; const d=Math.hypot(p.x-m.x,p.y-m.y); if(d<bd){bd=d;tgt=p;} }
    if(tgt){ const a=Math.atan2(tgt.y-m.y,tgt.x-m.x); m.x+=Math.cos(a)*(m.speed||160)*dt; m.y+=Math.sin(a)*(m.speed||160)*dt;
      if(bd<30){ damage(tgt,m.dmg,room.players[m.owner]||null,room); m.hp-=200; } }
  }
  // balas
  for(let i=st.bullets.length-1;i>=0;i--){
    const bl=st.bullets[i];
    bl.x+=bl.vx*dt; bl.y+=bl.vy*dt; bl.life-=dt;
    let dead=false;
    if(bl.life<=0||bl.x<0||bl.x>ARENA.w||bl.y<0||bl.y>ARENA.h) dead=true;
    if(!dead && collidesWall(bl.x,bl.y,4,room.mapIdx)){
      if(bl.ricochet && bl.bounces>0){ bl.bounces--; // ricocheteia (inverte componente mais penetrante)
        const w=MAPS[room.mapIdx].walls.find(w=>bl.x>w.x-6&&bl.x<w.x+w.w+6&&bl.y>w.y-6&&bl.y<w.y+w.h+6);
        if(w){ if(Math.abs(bl.vx)>Math.abs(bl.vy)) bl.vx*=-1; else bl.vy*=-1; } else {bl.vx*=-1;bl.vy*=-1;}
      } else dead=true;
    }
    if(!dead) for(const p of Object.values(room.players)){
      if(!p.alive||p.team===bl.team||bl.hit.includes(p.id)) continue;
      if(p.invisible>0 && bl.owner && Math.hypot(room.players[bl.owner]?.x||0,p.x)>400) continue;
      if(Math.hypot(bl.x-p.x,bl.y-p.y)<24){
        let dmg=bl.dmg*(p.dmgBoost?1.25:1);
        // rato emboscada
        if(bl.owner && room.players[bl.owner]?.ambush) dmg*=2.5;
        damage(p,dmg,room.players[bl.owner]||null,room);
        if(bl.lifesteal && room.players[bl.owner]) room.players[bl.owner].hp=Math.min(room.players[bl.owner].maxhp, room.players[bl.owner].hp+dmg*0.6);
        if(bl.slow) p.slow=Math.max(p.slow,bl.slow);
        if(bl.stun) p.stun=Math.max(p.stun,bl.stun);
        if(bl.blind) p.blind=Math.max(p.blind,bl.blind);
        if(bl.poison) p.poison=Math.max(p.poison,bl.poison);
        if(bl.aoe){ for(const e of allEnemies(room.players[bl.owner]||{team:bl.team},room)) if(Math.hypot(e.x-bl.x,e.y-bl.y)<bl.aoe) damage(e,dmg*0.7,room.players[bl.owner]||null,room); room.effects.push({type:'ring',x:bl.x,y:bl.y,r:0,max:bl.aoe,color:'#60a5fa',t:0.3}); }
        if(bl.puddle){ room.state.puddles=(room.state.puddles||[]); room.state.puddles.push({x:bl.x,y:bl.y,life:3}); }
        if(bl.pierce){ bl.hit.push(p.id); } else dead=true;
        break;
      }
    }
    if(dead) st.bullets.splice(i,1);
  }
  // poças (lesma)
  if(st.puddles) for(let i=st.puddles.length-1;i>=0;i--){const pu=st.puddles[i];pu.life-=dt;if(pu.life<=0){st.puddles.splice(i,1);continue;}
    for(const p of Object.values(room.players)){ if(p.alive&&Math.hypot(pu.x-p.x,pu.y-p.y)<50) damage(p,150,null,room); }}
  // cofre (heist)
  if(room.mode==='heist'){
    for(const p of Object.values(room.players)){
      if(!p.alive) continue;
      const safe = p.team==='blue' ? room.safeOrange : room.safeBlue;
      if(Math.hypot(p.x-(p.team==='blue'?1450:150), p.y-600)<120 && (p.input?.fire)){ safe.hp-=200; if(safe.hp<=0){ st.over=true; st.winner=p.team; } }
    }
  }
  // broadcast
  const slim = slimState(room);
  for(const [sid,sock] of Object.entries(room.sockets)){ try{ sock.emit('state', slim); }catch(e){} }
  if(st.over){ clearInterval(room.tickHandle); for(const [sid,sock] of Object.entries(room.sockets)){ try{ sock.emit('gameover', {winner:st.winner, blue:room.blueScore, orange:room.orangeScore}); }catch(e){} } }
}
function resetBall(room){ room.ball={x:800,y:600,vx:0,vy:0}; room.ballCarrier=null; for(const p of Object.values(room.players)) p.hasBall=false; }
function slimState(room){
  const players={};
  for(const [id,p] of Object.entries(room.players)) players[id]={id:p.id,nick:p.nick,bibo:p.bibo,team:p.team,x:p.x,y:p.y,hp:p.hp,maxhp:p.maxhp,alive:p.alive,angle:p.angle||0,superCharge:p.superCharge,gadgetCharges:p.gadgetCharges,gadgetCd:p.gadgetCd,stun:p.stun,slow:p.slow,poison:p.poison,invisible:p.invisible,invuln:p.invuln,flying:p.flying,rolling:p.rolling,shield:p.shield,kills:p.kills||0,stars:p.stars||0,gems:p.gems||0,hasBall:p.hasBall,minions:p.minions||0,isBot:p.isBot};
  return {players, bullets:room.state.bullets.slice(0,60), minions:(room.state.minions||[]).slice(0,20), powerups:room.state.powerups, gems:room.state.gems||[], t:room.state.t, over:room.state.over, winner:room.state.winner, mapIdx:room.mapIdx, mode:room.mode, blueScore:room.blueScore, orangeScore:room.orangeScore, gemsBlue:room.gemsBlue, gemsOrange:room.gemsOrange, gemTimer:room.gemTimer||0, ball:room.ball, ballCarrier:room.ballCarrier||null, safeBlue:room.safeBlue, safeOrange:room.safeOrange, effects:room.effects.slice(0,10), puddles:(room.state.puddles||[]).slice(0,15), bushes:room.state.bushes, showdownShrink:room.showdownShrink||0};
}

// ============ SOCKET ============
io.on('connection', socket=>{
  socket.on('createRoom', ({nick, bibo, mode, mapIdx}, cb)=>{
    let code; do{ code=randCode(); }while(rooms[code]);
    const room=newRoom(code, mode||'gemgrab', mapIdx||0);
    rooms[code]=room;
    const pid='p'+socket.id;
    room.players[pid]={id:pid, nick:nick||'Jogador', bibo:bibo||0, team:'blue', isBot:false, kills:0, stars:0, gems:0, input:{mx:0,my:0,ax:1,ay:0,fire:false}};
    spawnPlayer(room.players[pid],'blue');
    room.sockets[pid]=socket;
    socket.join(code); socket.data={code, pid};
    fillBots(room);
    cb({ok:true, code, pid});
  });
  socket.on('joinRoom', ({nick, bibo, code}, cb)=>{
    code=(code||'').toUpperCase();
    const room=rooms[code];
    if(!room) return cb({ok:false, error:'Sala não encontrada'});
    const humans=Object.values(room.players).filter(p=>!p.isBot).length;
    if(humans>=6) return cb({ok:false, error:'Sala cheia'});
    // remove um bot para dar lugar
    const botIds=Object.keys(room.players).filter(id=>room.players[id].isBot);
    if(botIds.length>0){ const bid=botIds[0]; delete room.players[bid]; }
    const pid='p'+socket.id;
    const team = Object.values(room.players).filter(p=>p.team==='blue').length <= Object.values(room.players).filter(p=>p.team==='orange').length ? 'blue' : 'orange';
    room.players[pid]={id:pid, nick:nick||'Jogador', bibo:bibo||0, team, isBot:false, kills:0, stars:0, gems:0, input:{mx:0,my:0,ax:1,ay:0,fire:false}};
    spawnPlayer(room.players[pid], team);
    room.sockets[pid]=socket;
    socket.join(code); socket.data={code, pid};
    fillBots(room);
    if(!room.started){ room.started=true; room.tickHandle=setInterval(()=>tickRoom(room), TICK); }
    cb({ok:true, pid, team});
  });
  socket.on('input', (inp)=>{
    const d=socket.data; if(!d||!rooms[d.code]) return;
    const p=rooms[d.code].players[d.pid]; if(p) p.input=inp;
  });
  socket.on('startGame', ()=>{
    const d=socket.data; if(!d||!rooms[d.code]) return;
    const room=rooms[d.code];
    if(!room.started){ room.started=true; room.tickHandle=setInterval(()=>tickRoom(room), TICK); io.to(d.code).emit('started'); }
  });
  socket.on('disconnect', ()=>{
    const d=socket.data; if(!d||!rooms[d.code]) return;
    const room=rooms[d.code];
    delete room.players[d.pid]; delete room.sockets[d.pid];
    fillBots(room);
    if(Object.keys(room.sockets).length===0){ clearInterval(room.tickHandle); delete rooms[d.code]; }
  });
});
function fillBots(room){
  const total=Object.keys(room.players).length;
  const need=Math.max(0,6-total);
  let slot=Object.keys(room.players).length;
  for(let i=0;i<need;i++){
    const team = Object.values(room.players).filter(p=>p.team==='blue').length <= Object.values(room.players).filter(p=>p.team==='orange').length ? 'blue' : 'orange';
    const bot=makeBot(team, slot++);
    room.players[bot.id]=bot;
  }
  if(!room.started && Object.keys(room.players).length>=2){ room.started=true; room.tickHandle=setInterval(()=>tickRoom(room), TICK); }
}

server.listen(PORT, ()=>console.log(`🐛 BIBOS BRAWL rodando em http://localhost:${PORT}`));
